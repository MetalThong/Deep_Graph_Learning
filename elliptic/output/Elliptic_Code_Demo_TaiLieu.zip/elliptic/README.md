# Elliptic: phát hiện giao dịch Bitcoin đáng ngờ

Bộ độc lập bổ sung cho bài thuyết trình Deep Graph. Mục tiêu là học và kiểm chứng việc dùng graph cho phân loại giao dịch lịch sử.

## Mở kết quả

- Demo: https://elliptic-transaction-lab.pinkwand512.chatgpt.site (quyền riêng tư của tài khoản chủ site).
- `output/Elliptic_Deep_Graph_26_Slides.pptx`: 26 slide chỉnh sửa được, có speaker notes. Kịch bản một người, khoảng 38 phút gồm 7 phút demo, thêm 2 phút hỏi đáp.
- `output/Elliptic_Loi_Thuyet_Trinh_Va_Demo.pdf`: 16 trang, lời nói theo từng slide và kịch bản thao tác.
- `output/Elliptic_Tai_Lieu_Hoc_3_Ngay.pdf`: 14 trang, lịch học, thuật ngữ, bài tập, đáp án và phản biện.
- Demo còn có `learn.html`, đọc tài liệu và tải PowerPoint/PDF ngay trên web.

## Chạy demo không cần mạng

Máy chỉ cần Python 3 để phục vụ file tĩnh. Không cần cài Torch để xem demo.

```powershell
python -m http.server 8767 --bind 127.0.0.1 --directory site/dist
```

Mở http://127.0.0.1:8767. Dừng bằng Ctrl+C. Có thể chạy `start_demo.ps1` từ PowerShell. Không mở index.html bằng nhấp đôi vì trình duyệt có thể chặn fetch dữ liệu qua file://.

## Huấn luyện lại

Python 3.11+ được khuyến nghị. Lượt thực nghiệm đi kèm dùng môi trường ghi trong `results/metrics.json`; các phiên bản chính có trong `requirements-lock.txt`.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe prepare_data.py
.\.venv\Scripts\python.exe train.py --threads 4 --seeds 0 1 2 --force
.\.venv\Scripts\python.exe export_demo.py
.\.venv\Scripts\python.exe verify_results.py
node verify_inference.mjs
```

`prepare_data.py` tải dữ liệu công khai từ nguồn Kaggle và kiểm tra cấu trúc. Nếu nguồn tải yêu cầu đăng nhập trong tương lai, tải bộ gốc từ trang nguồn rồi đặt ba CSV vào `data/elliptic_bitcoin_dataset/`. Archive giao cho người học không chứa CSV gốc hoặc prepared.npz vì dung lượng lớn; demo đã có đủ 15 snapshot test để chạy độc lập.

`train.py` mặc định tái sử dụng các kết quả đã lưu. `--force` chủ động huấn luyện lại và ghi đè các run được chọn. Hãy sao chép thư mục trước khi thử cấu hình khác nếu muốn giữ bản báo cáo hiện tại. Các lựa chọn `--models rf_local rf_all mlp gcn`, `--epochs 180`, `--seeds 0 1 2` cho phép thu hẹp một lượt chạy.

## Giao thức thực nghiệm

- Gốc: 203.769 giao dịch, 234.355 cạnh, 49 timestep. Nhãn: illicit=1, licit=0, unknown=-1 trong code.
- Train timestep 1-29, validation 30-34, test 35-49. Test có 16.670 nút có nhãn và 50.834 unknown.
- Không dùng ID hoặc timestep làm feature. 93 cột local dạng số; RF all thêm 72 cột tổng hợp có sẵn từ nhà cung cấp.
- StandardScaler fit trên tất cả nút train, không fit validation/test. Đây là chuẩn hóa bổ sung trên các giá trị benchmark đã được bên cung cấp xử lý và ẩn danh.
- Unknown tham gia graph, không tham gia supervised loss hoặc chỉ số có nhãn. Không dùng nhãn làm đầu vào.
- GCN: graph nhị phân đối xứng, self-loop, chuẩn hóa đối xứng theo bậc. Hai lớp, hidden 64, ReLU, dropout 0,2, nhánh linear skip từ X vào logit. MLP cùng tham số nhưng A=I. Mỗi mạng có 6.174 tham số.
- Adam lr 0,003, weight decay 0,0005; BCE với trọng số dương = số licit / số illicit train. Tối đa 180 epoch, patience 30, theo AP validation. Không chọn lại cấu hình sau khi xem test.
- RF: 200 cây, min_samples_leaf=2, max_features=sqrt, class_weight=balanced_subsample.
- Ngưỡng tối đa hóa F1 validation, riêng từng model/seed. Điểm làm tròn sáu chữ số trước chọn ngưỡng và báo cáo để ổn định tie do số thực. Test không chọn ngưỡng.
- Ba seed 0/1/2; báo cáo trung bình và SD mẫu (ddof=1). Không coi SD là khoảng tin cậy.

## Kết quả chính

| Mô hình | F1 trung bình | SD (điểm phần trăm) |
|---|---:|---:|
| Random Forest local | 77,0% | 1,6 |
| Random Forest all | 79,3% | 1,1 |
| MLP | 52,4% | 2,6 |
| GCN + skip | 36,5% | 2,1 |

GCN chưa vượt đối chứng trong cấu hình này. RF all đã có thông tin hàng xóm dưới dạng feature tổng hợp nên không mô tả nó là mô hình hoàn toàn không có thông tin quan hệ. GCN đạt checkpoint tốt nhất ở epoch 179 trong cả ba seed, sát ngân sách; kết quả không chứng minh đã tối ưu hết kiến trúc. Các con số chính xác, Precision/Recall/AP và confusion matrix nằm trong `results/metrics.json`.

## Demo suy luận thế nào?

- GCN và MLP dùng checkpoint seed 0 và tính trực tiếp trong JavaScript trên toàn bộ snapshot đã chọn.
- RF dùng điểm seed 0 tính trước bằng Python.
- Thanh ngưỡng thay đổi quyết định và số đếm test; không huấn luyện lại và không thay bảng báo cáo.
- Graph hiển thị tối đa 50 nút để dễ đọc. Cắt hình không cắt graph suy luận.
- Màu mặc định theo dự đoán của mô hình đang chọn. Bấm đối chiếu để chuyển sang nhãn tham chiếu, với unknown màu xám.
- Điểm mô hình chưa được hiệu chỉnh xác suất.
- Năm tình huống có ID thật được chọn sau đánh giá để minh họa, không phải mẫu đại diện ngẫu nhiên.

## Giới hạn

Đây là phân loại snapshot lịch sử. Graph có thể chứa giao dịch downstream trong cùng timestep; kết quả không chứng minh khả năng phát hiện ngay lúc giao dịch mới phát sinh. Dữ liệu ẩn danh, phần lớn unknown; không được suy diễn tên chủ ví, số tiền thực hoặc hành vi pháp lý của một cá nhân. Graph hiển thị là công cụ khám phá, chưa phải phương pháp giải thích nhân quả. Một split, kiến trúc gọn và ba seed chưa đánh giá đầy đủ tính tổng quát.

## Các file kiểm chứng

`qa/metrics-integrity.json`: kiểm tra chỉ số và chronology cho 12 run. `qa/inference-parity.json`: JavaScript so với PyTorch trên 135.008 đầu ra neural. `qa/browser-report.json`: chức năng desktop/mobile. `presentation/.build/validation-final.json`: package, font, native chart/table và import PowerPoint bằng Artifact Tool. Slide và PDF đã render để kiểm tra bố cục; không tuyên bố đã mở trong Microsoft PowerPoint.

## Nguồn

- Elliptic gốc: https://www.kaggle.com/datasets/ellipticco/elliptic-data-set
- Weber et al. (2019): https://arxiv.org/abs/1908.02591
- Kipf & Welling, GCN: https://arxiv.org/abs/1609.02907

Giữ thông tin nguồn khi chia sẻ. Kiểm tra điều kiện của nhà cung cấp nếu tái phân phối dữ liệu hoặc dùng ngoài phạm vi học tập. Không coi các file trong bộ này là một giấy phép mới cho dữ liệu Elliptic.
